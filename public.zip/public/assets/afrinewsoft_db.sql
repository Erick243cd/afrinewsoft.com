-- --------------------------------------------------------
-- Hôte :                        127.0.0.1
-- Version du serveur:           5.7.24 - MySQL Community Server (GPL)
-- SE du serveur:                Win64
-- HeidiSQL Version:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Listage de la structure de la table afrinewsoft_db. afriservices
CREATE TABLE IF NOT EXISTS `afriservices` (
  `serviceId` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `serviceName_fr` varchar(100) NOT NULL,
  `serviceDescription_fr` text,
  `serviceName_en` varchar(100) NOT NULL,
  `serviceDescription_en` text,
  `serviceImage` varchar(100) NOT NULL,
  `data_aos_delay` int(11) NOT NULL,
  `serviceCover` varchar(100) NOT NULL,
  `serviceSlug` varchar(100) NOT NULL,
  PRIMARY KEY (`serviceId`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- Listage des données de la table afrinewsoft_db.afriservices : ~7 rows (environ)
/*!40000 ALTER TABLE `afriservices` DISABLE KEYS */;
INSERT INTO `afriservices` (`serviceId`, `serviceName_fr`, `serviceDescription_fr`, `serviceName_en`, `serviceDescription_en`, `serviceImage`, `data_aos_delay`, `serviceCover`, `serviceSlug`) VALUES
	(1, 'Conception graphique', 'Etant donné que le Design graphique fait partie des étapes clés de la communication visuelle pour votre entreprise ou pour vous-même ; nous  mettons un accent particulier sur la conception de votre logo, vos flyers, vos bannières publicitaires et même votre site web.<p>Nous faisons une combinaison propre des images, textes pour l’affichage à l’écran et pour l’impression, ensuite nous vous présentons le résultat et attendons votre validation car nous restons prêts pour tout apport de modification selon votre demande. Nous faisons de votre satisfaction une priorité, et surtout quand il s’agit de votre <b><i>identité visuelle</i></b>.</p>', 'Graphic design', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum', '001-ux.png', 0, 'graphic-design-afrinewsoft .webp', 'graphic-design'),
	(2, 'Conception des logiciels', 'Chez Afrinewsoft, Concevoir un logiciel ne s’arrête pas seulement à l’implémentation des fonctionnalités demandées par le client, mais au contraire nous faisons une étude approfondie de besoins du client, et faisons le choix des technologies et d’architecture de sorte que logiciel à livrer soit agile. </br><p>Partant de la conception, nous passons par tous les tests possibles pour nous rassurer sur la robustesse, la sécurité, l’utilisabilité ainsi que l’agilité du logiciel que nous vous livrons. </br>Nous vous garantissons la sécurité de vos données contre tout type d’attaques malveillantes.</p><p>Vous êtes une entreprise, un établissement scolaire ou commercial, une ONG, un service privé ou public et vous désirer informatiser la gestion de vos activités, alors nous vous invitons de nous confier vos projets tout en vous rassurant que vous serez satisfait par notre savoir-faire. </p>', 'Software Designer', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum', '005-web-development.png', 100, 'software-design-afrinewsoft-transp.webp', 'software-designer'),
	(4, 'Développement Web', 'Comme nous l’avons mentionné sur la <a href="http://localhost/afrinewsoft.co/services/software-designer">Conception logiciel</a>,  Nous ajoutons ici que nous concevons des sites web dynamiques, vitrines, portfolio, E-commerce, pour la présentation de vos activités et renforcement de votre image ou celle de votre entreprise.<p>Nous vous invitons également à suivre nos conseils sur <a href="<?= site_url(\'services/conseil) ?>"> la nécessité d’avoir un Site Web professionnel.</a></p>', 'Web Development', 'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.', '007-world-wide-web-1.png', 200, 'web-development-afrinewsoft.webp', 'web-development'),
	(5, 'Photographie événementielle', 'Pour l’immortalisation de vos événements, nous vous facilitons la couverture par la photographie et la vidéographie ; avec des appareils de la récente technologie ainsi qu’une équipe qualifiée dans la prise et traitement des images.<p>Pour la réalisation de vidéos de longue durée, nous sommes en partenariat  avec <b>DREAM STUDIO</b>, qui est une entreprise spécialisée dans la réalisation et production des vidéos et photos Et dans la ville de Lubumbashi. </p> Nous invitons à visiter <a href="https://web.facebook.com/dreamstudio874" target="_blanck"> DREAM STUDIO </a> sur leur page Facebook.', 'Event photography', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum', '008-photography.png', 300, 'event-photography-afrinewsoft.webp', 'event-photography'),
	(6, 'Marketing Digital', 'Grace aux canaux numériques, nous nous sommes engagés de vous accompagner dans la vente de vos produits et services. Nous vous aidons à augmenter les visites de votre site web et les transformer en acte d’achat. <p>Si vous avez des produits ou services que vous voulez vendre mais vous ne savez pas atteindre le public qui est censé de vous consommer, nous sommes la solution qu’il vous faut pour la croissance de vos activités.</p>', 'Digital Marketing', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum', '014-social-media-1.png', 0, 'digital-marketing-afrinewsoft.webp', 'digital-marketing'),
	(7, 'Impression tout support', 'Grace aux canaux numériques, nous nous sommes engagés de vous accompagner dans la vente de vos produits et services. Nous vous aidons à augmenter les visites de votre site web et les transformer en acte d’achat. <p>Si vous avez des produits ou services que vous voulez vendre mais vous ne savez pas atteindre le public qui est censé de vous consommer, nous sommes la solution qu’il vous faut pour la croissance de vos activités.</p>', 'Printing on all supports', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur, explicabo. Suscipit blanditiis, eligendi veniam voluptatibus eius alias similique minus tempora quaerat sit. Ducimus odio magni accusantium alias molestiae doloremque soluta.', '015-3d-printer.png', 100, 'print-all-support-afrinewsoft.webp', 'printing-on-all-supports'),
	(8, 'Installation de caméras de surveillance', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur, explicabo. Suscipit blanditiis, eligendi veniam voluptatibus eius alias similique minus tempora quaerat sit. Ducimus odio magni accusantium alias molestiae doloremque soluta.', 'Installation of surveillance cameras', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur, explicabo. Suscipit blanditiis, eligendi veniam voluptatibus eius alias similique minus tempora quaerat sit. Ducimus odio magni accusantium alias molestiae doloremque soluta.', '018-cctv-camera.png', 100, 'camera-surveillance-afrinewsoft.webp', 'installation-of-urveillance-cameras'),
	(9, 'Installation et Administration réseaux', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur, explicabo. Suscipit blanditiis, eligendi veniam voluptatibus eius alias similique minus tempora quaerat sit. Ducimus odio magni accusantium alias molestiae doloremque soluta.', 'Network installation and administration', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur, explicabo. Suscipit blanditiis, eligendi veniam voluptatibus eius alias similique minus tempora quaerat sit. Ducimus odio magni accusantium alias molestiae doloremque soluta.', '021-cloud-computing.png', 100, 'networking-installation.webp', 'network-installation-and-administration');
/*!40000 ALTER TABLE `afriservices` ENABLE KEYS */;

-- Listage de la structure de la table afrinewsoft_db. migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Listage des données de la table afrinewsoft_db.migrations : ~0 rows (environ)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
