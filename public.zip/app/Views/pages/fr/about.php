<?= $this->extend('layouts/app') ?>
<?= $this->section('content') ?>
<div class="hero bg-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6 text-center">
                <span class="subheading d-block mb-2 text-uppercase" data-aos="fade-up">A propos</span>
                <h1 class="heading mb-4" data-aos="fade-up" data-aos-delay="100">Qui sommes-nous </h1>
                <p class="w-75 mx-auto mb-5" data-aos="fade-up" data-aos-delay="200">
                    Afrinewsoft est une entreprise informatique qui conçoit des logiciels informatiques, des sites web,
                    et vous fournit également des services dans le marketing digital, l'imprimerie sur divers supports,
                    la photographie événementielle et tout autre service lié aux nouvelles technologies de l'information
                    et de communication.
                </p>
                <p data-aos="fade-up" data-aos-delay="300"><a href="<?= site_url('/services') ?>"
                                                              title="Voir tous nos services" class="btn btn-primary">Nos
                        services</a></p>
            </div>
            <div class="col-lg-4">
                <div class="img-fluid rounded mt-5">
                    <?= img('public/assets/images/afrinewsoft-cover.webp', '', 'class="img-fluid" alt="Afrinewsoft home picture" data-aos="fade-up"  data-aos-delay="200" style="border-radius:5px"') ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="section sec-welcome">
    <div class="container">
        <div class="row g-0 align-items-stretch">
            <div class="col-lg-6" data-aos="fade-right">
                <div class="img-wrap">
                    <img src="<?= site_url('public/assets/images/afrinewsoft-about-realisations.webp') ?>" alt="Image"
                         class="img-fluid">
                </div>
            </div>
            <div class="col-lg-6 align-self-end" data-aos="fade-up" data-aos-delay="100">
                <div class="box h-100">
                    <p class="mb-5">Par des solutions informatiques intélligentes et évolutives, nous améliorons la gestion quotidienne des activités au sein des organisations et au près des personnes privées.</p>
                    <p><a title="Afrinewsoft Contact" href="<?= site_url('contact') ?>"
                          class="btn btn-outline-dark-bg has-arrow">Contactez-nous<span
                                    class="icon-keyboard_backspace"></span></a></p>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="section pt-0">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-5" data-aos="fade-up" data-aos-delay="0">
                <span class="subheading">A propos de nous</span>
                <h3 class="heading mb-4">Nous vous accompagnons</h3>
                <div class="excerpt">
                    <p>
                        Nous accompagnons les PME dans l'utilisation ou la consommation de web
                        services et particulièrement dans le marketing digital.
                    </p>
                    <p class="mb-4">Avec beaucoup d'expériences, nos équipes travaillent quotidiennement pour concevoir des logiciels dans le respect de délai, d'architecture et de normes d'agilité.
                        Afrinewsoft vous garantie la sécurité et le respect de la vie privée sur l'ensemble des produits et services qui vous sont fournis.
                        Nous sommes disponnibles et permanents pour toute assistance technique sur les problèmes que nos utilisateurs rencontrent.</p>
                    <p class="mb-4">
                        Profitez de notre expérience et savoir-faire dans le développement des solutions numériques et dans la fourniture des services liés aux technologies informatiques .
                    </p>
                </div>

            </div>
            <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
                <img src="<?= site_url('public/assets/images/intact-picture-afrinewsoft.webp') ?>" alt="Afrinewsoft"
                     class="img-fluid">
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
